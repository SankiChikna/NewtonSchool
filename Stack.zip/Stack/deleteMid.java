public class deleteMid {
    
}
